CTR_Toolkit
=============

Legal, open source, 3DS toolkit. Compiles under Linux and Windows(MinGW).

1/ make_cia - Generates CIA files

2/ make_banner - Generates ICN/BNR files

3/ make_cdn_cia - Repackages CDN content into a CIA file

4/ extdata_tool - Extracts standalone and FS Extdata, and can process Title Database files

5/ iconcache_tool - Extracts cached icon data from homemenu extdata

