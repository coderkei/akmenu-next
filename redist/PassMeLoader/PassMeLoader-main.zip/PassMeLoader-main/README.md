# PassMeLoader

## Usage:
1. Have a PassMe-capable Slot-2 device
1. Run it from your favourite homebrew menu or kernel
1. You are now in Slot-2 NDS mode!

## Building
1. Install BlocksDS: https://github.com/blocksds/sdk/blob/master/readme.rst
1. Run `make`
