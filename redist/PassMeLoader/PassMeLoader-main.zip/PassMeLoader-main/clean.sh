make -C bootloader clean
make clean
rm -rf data
