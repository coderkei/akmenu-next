#pragma once

void insert_arm9_payload();
void insert_arm7_payload();
