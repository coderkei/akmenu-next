void free_buffers(ROM_CONTEXT *ctx);
int argv_check(char *string, int argc, int index);